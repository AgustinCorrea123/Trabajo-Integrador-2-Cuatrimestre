#include "Herramientas.h"

using namespace std;

struct fecha{
	int dia;
	int mes;
	int anio;
};

struct usuario{
    char apeNom[60];
	char usuario[10];
	char contrasenia[10];
    char tipoUsuario;
	int dni;
};

struct cliente{
	char apeNom[60];
	char domicilio[60];
	int dni;
	char localidad[60];
	fecha fechaDeNac;
	float peso;
	char telefono[25];
};
struct profesional{
	char apeNom[60];
    int idProfesional;
	int dni;
	char telefono[25];
};

struct turnos{
	int idProf;
	fecha fec;
	int dniCliente;
    char detalles[382];
    bool atendido;
};

struct atenciones{
	char apeNom[60];
	int cantAten;
	float porc;
};

bool login();
void listaDeEspera();
void registrarEvolucion();
void password(int x, int y, char contrasenia[]);
void menuPrincipal();

usuario admin;
profesional datos;

const char *titulo[]={"LISTA DE ESPERA", "REGISTRAR EVOLUCION"};

int main(int argc, char const *argv[])
{
    bool band=false;
	system("mode 120, 35");
        if(login()==true) {
            band = true;
        }
        if(band==true){
        	system("cls");
    		menuPrincipal();
		}
    
    return 0;
}

void menuPrincipal(){
	bool band=true;
	int Op;
	const char *titulo= "Modulo de Profesionales";
	const char *opciones[]={"Visualizar Lista de Espera", "Registrar Evolucion", "Salir"};
	
	do{
		system("cls");
		textcolor(WHITE);
		marco();
		for(int i=35; i<88+1; i++){
		gotoxy(i, 20); printf("%c", 219);
		gotoxy(i, 25); printf("%c", 219);
		}
		for(int i=20; i<25+1; i++){
			gotoxy(35, i); printf("%c", 178);
			gotoxy(88, i); printf("%c", 178);
		}
		textcolor(YELLOW);
		gotoxy(38, 22); printf("USUARIO: %s", admin.usuario);
		gotoxy(38, 23); printf("NOMBRE: %s", admin.apeNom);
		textcolor(WHITE);
            for(int i=0; i<3; i++){
		        gotoxy(44, 10+i); printf("%d- %s", i+1, opciones[i]);
	        }
		gotoxy(44,15); printf("Ingrese una opcion: ");
        scanf("%d", &Op);
		switch(Op){
			case 1: system("cls"); listaDeEspera();
				break;
			case 2: system("cls");registrarEvolucion();
				break;
			case 3: band=false;
				break;
		}
	}while(band);
	system("cls");
	gotoxy(40, 12); printf("Se cerro el modulo de Profesionales. Adios...\n\n\n\n");
	system("pause>nul");
}

void password(int x, int y, char contrasenia[]){
	int i=0;
	char pass[32], caracter;
	
	gotoxy(x,y);
	caracter=getch();
	while(caracter!=ENTER){
		if (caracter==8)
		{
			if (i>0)
			{
				i--;
				printf("\b \b");
			}
		}else if(i!=32)
		{
			printf("*");
			pass[i]=caracter;
			i++;
		}
		caracter=getch();	
	}
	pass[i]='\0';
	strcpy(contrasenia,pass);
}

bool login(){
    FILE *arch=fopen("Usuarios.dat", "r+b");
	FILE *arch1=fopen("Profesionales.dat", "r+b");
    usuario user;
    bool band=false;
    
    rewind(arch);
    if (arch==NULL and arch1==NULL)
    {
        gotoxy(23, 14); printf("No se ha registrado ningun usuario. Por favor solicite uno para poder continuar.\n\n\n\n");
        system("pause>nul");
        return false;
    }else{
        do{
            textcolor(RED);
            marcoGenerico(25,95,9,23);
            textcolor(BLACK);
            textbackground(WHITE);
            gotoxy(50, 9); printf(" INGRESO DE USUARIO ");
            textbackground(BLACK);
            textcolor(WHITE);
            gotoxy(50-10, 15);printf("USUARIO: ");
            gotoxy(50-13, 17);printf("CONTRASE%cA: ", 165);
            _flushall();
            gotoxy(58-10, 15); textbackground(WHITE); printf("                                 ");
            gotoxy(61-13, 17); textbackground(WHITE); printf("                                 ");
            textcolor(BLACK);
            gotoxy(58-10, 15); gets(user.usuario);
            password(61-13, 17 , user.contrasenia);
            textcolor(WHITE);
            textbackground(BLACK);
            rewind(arch);
            fread(&admin,sizeof(usuario),1,arch);
            while(!feof(arch)){
                if(strcmp(user.usuario,admin.usuario)==0){
                    band=true;
                    break; 
                }
                fread(&admin,sizeof(usuario),1,arch);
            }
            if(band==true){
                if(admin.tipoUsuario == 'P' || admin.tipoUsuario == 'p'){
                    if(strcmp(user.contrasenia,admin.contrasenia)==0){
                            band=true;
                            system("cls");
					}else{
                        textcolor(WHITE);
                        textbackground(LIGHTRED);
                        gotoxy(19-8, 21+7); printf(" %cNOTA: ", 175);
                        textcolor(BLACK);
                        textbackground(WHITE);
                        gotoxy(26-7, 21+7); printf(" La contrase%ca no coincide con el usuario. ", 164);
                        textbackground(BLACK);
                        system("pause>nul");
                        system("cls");	
                        band=false;	
					}
                }else{
                    textcolor(WHITE);
                    textbackground(LIGHTRED);
                    gotoxy(19-8, 21+7); printf(" %cNOTA: ", 175);
                    textcolor(BLACK);
                    textbackground(WHITE);
                    gotoxy(26-7, 21+7); printf(" Solo los PROFESIONALES pueden ingresar a este modulo. ");
                    textbackground(BLACK);
                    textcolor(WHITE);
                    system("pause>nul");
                    system("cls");
                    band=false;	
                }
            }else{
                textcolor(WHITE);
                textbackground(LIGHTRED);
                gotoxy(19-8, 21+7); printf(" %cNOTA: ", 175);
                textcolor(BLACK);
                textbackground(WHITE);
                gotoxy(26-7, 21+7); printf(" El usuario no existe. ");
                textbackground(BLACK);
                system("pause>nul");
                system("cls");
            }
        } while (band==false);
        rewind(arch1);
		fread(&datos,sizeof(profesional),1,arch1);
       	 	while(!feof(arch1)){
					if(admin.dni==datos.dni) break;
						fread(&datos,sizeof(profesional),1,arch1);
			}
		fclose(arch);
		fclose(arch1);
    	return true;
    }
}

void listaDeEspera(){
	turnos tur;
	cliente client;
	int dniClient;
	bool band=false,turnoparaProf=false;
	char opc;
	char nombreCliente[60];

	FILE *arch=fopen("Turnos.dat","r+b");
	FILE *arch2=fopen("Clientes.dat","r+b");
	if(arch==NULL){
		printf("\n\t\tNo se registro ningun turno...");
		system("pause");
	}
	else if(arch2==NULL){
		printf("\n\t\tNo se registro ninguna paciente...");
		system("pause");
	}
	else{
		titulo_Generico(titulo, 0, 19, 4, 101, 4);
		rewind(arch);
		fread(&tur, sizeof(tur), 1, arch);
			while (!feof(arch)){
					if (tur.idProf == datos.idProfesional){
						if (tur.atendido == false){
					    	rewind(arch2);
					    	fread(&client,sizeof(cliente),1,arch2);
								while(!feof(arch2)){
										if(tur.dniCliente==client.dni){
											strcpy(nombreCliente,client.apeNom);
										}
									fread(&client,sizeof(cliente),1,arch2);
								}
							printf("\n\n\t\t\t%cNombre del paciente: %s\n", 175, nombreCliente);
							printf("\t\t\t%cDNI del paciente: %d\n", 175, tur.dniCliente);
							printf("\t\t\t%cFecha de turno: %d/%d/%d\n", 175, tur.fec.dia, tur.fec.mes, tur.fec.anio);
							printf("\n\t\t     ==============================================================================\n");
							turnoparaProf = true;
						}
					}
					fread(&tur, sizeof(tur), 1, arch);
				}
		}
			if(turnoparaProf==true){
				do{
					printf("\n\t\t\tDesea ver informacion de algun paciente? [s/n]: ");
					fflush(stdin);
					scanf("%c",&opc);
					if(opc == 's' || opc == 'S'){
						printf("\n\t\tIngrese DNI del paciente: ");
						scanf("%d",&dniClient);
						band=false;
						rewind(arch2);
						fread(&client,sizeof(cliente),1,arch2);
						while(!feof(arch2) && band==false){
							if(dniClient==client.dni){
								printf("\n\n\t\t%cNombre del paciente: %s", 175, client.apeNom);
								printf("\n\t\t%cPeso: %.2f Kg", 175, client.peso);
								printf("\n\t\t%cFecha de nacimiento: %d/%d/%d", 175, client.fechaDeNac.dia, client.fechaDeNac.mes, client.fechaDeNac.anio);
								printf("\n\t\t%cLocalidad: %s", 175, client.localidad);
								printf("\n\t\t%cDomicilio: %s", 175, client.domicilio);
								printf("\n\t\t%cDNI del paciente: %d", 175, client.dni);
								printf("\n\t\t%cTelefono: %d", 175, client.telefono);
								band=true;
							}
							fread(&client,sizeof(cliente),1,arch2);
						}
						if(band==false){
							printf("\n\t\tNo se registro ningun paciente con dicho dni...");
							system("pause>nul");
						}
					}
				}while(opc == 's' || opc == 'S');
			}else{
				gotoxy(44, 10); printf("No hay turnos registrados...");
				system("pause>nul");
			}
	fclose(arch);
	fclose(arch2);
}

void registrarEvolucion(){
	turnos tur;
	fecha fechaturno;
	cliente client;
	int dniCliente;
	bool band=false, turnoparaProf=false;
	char  opc='n';
	char nombreCliente[60];
	
	FILE *arch = fopen("Turnos.dat", "r+b");
	FILE *arch2=fopen("Clientes.dat","r+b");
	if(arch==NULL){
		printf("\n\t\tNo hay turnos disponibles para registrar evolucion...");
		system("pause");
	}else{
		do{
			system("cls");
			titulo_Generico(titulo, 1, 19, 4, 101, 4);
			rewind(arch);
			fread(&tur, sizeof(tur), 1, arch);
			while (!feof(arch)){
					if (tur.idProf == datos.idProfesional){
						if (tur.atendido == false){
					    	rewind(arch2);
					    	fread(&client,sizeof(cliente),1,arch2);
							while(!feof(arch2)){
								if(tur.dniCliente == client.dni){
									strcpy(nombreCliente,client.apeNom);
									break;
								}
								fread(&client,sizeof(cliente),1,arch2);
							}
							
							printf("\n\n\t\t\t%cNombre del paciente: %s\n", 175,nombreCliente);
							printf("\t\t\t%cDNI del paciente: %d\n", 175, tur.dniCliente);
							printf("\t\t\t%cFecha en la que se otorgo el turno: %d/%d/%d\n",  175, tur.fec.dia, tur.fec.mes, tur.fec.anio);
							printf("\n\t\t     ==============================================================================");
							turnoparaProf = true;
						}
					}
					fread(&tur, sizeof(tur), 1, arch);
			}
			
			printf("\n\n\t\t\t%cIngrese Nombre y Apellido del paciente: ", 175);
			fflush(stdin);
			gets(nombreCliente);
			
			rewind(arch2);
			fread(&client,sizeof(cliente),1,arch2);
			while(!feof(arch2)){
				if(strcmp(nombreCliente,client.apeNom)==0){
					dniCliente=client.dni;
				}
				fread(&client,sizeof(cliente),1,arch2);	
			}

			rewind(arch);
			fread(&tur,sizeof(turnos),1,arch);
			while(!feof(arch)){
				if(tur.dniCliente==dniCliente && tur.atendido==false)
					{
						band=true;
						printf("\n\t\t\t%cEvolucion del paciente: ", 175);
						fflush(stdin);
						gets(tur.detalles);
						tur.atendido = true;
						fseek(arch,-sizeof(turnos), SEEK_CUR);
						fwrite(&tur,sizeof(turnos),1,arch);
						break;
					}
				fread(&tur, sizeof(turnos), 1, arch);
			}
			
			if(band==false){
				printf("\n\t\t       El paciente no pudo ser encontrado, desea intentar nuevamente? [s/n]: ");
				fflush(stdin);
				scanf("%c",&opc);
				system("cls");
			}
			else{
				printf("\n\n\t\t\t             Evolucion registrada con exito...");
				system("pause>nul");
			}
		
		}while(opc=='s' || opc=='S');
	}
	fclose(arch);
	fclose(arch2);
}


